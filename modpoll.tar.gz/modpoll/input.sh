#! /usr/bin/zsh
./modpoll -m rtu -b 9600 -p none -a 247 -t 3$3 -0 -1 -r $1 $2 /dev/ttyUSB0 2> /dev/null | grep -i "\["
#./modpoll -m tcp -p 502 -a 247 -t 3$3 -0 -1 -r $1 $2 192.168.0.32 2> /dev/null | grep -i "\["