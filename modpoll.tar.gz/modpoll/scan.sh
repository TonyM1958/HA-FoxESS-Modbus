#! /usr/bin/zsh
addr=$2
echo $1
for i in {1..$4}
do
    ./$1.sh $addr
    let addr+=$3
done