#! /usr/bin/zsh
./modpoll -m rtu -b 9600 -p none -a 247 -t 4$3 -0 -1 -r $1 $2 /dev/ttyUSB0  2> /dev/null | grep -i "\["
